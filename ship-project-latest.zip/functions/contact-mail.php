<?php 

$from = "noreply@adora-solutions.com";

$to      = $_POST['email'];
$subject = 'Interested in '.$_POST['service'];
$message = "Name: ".$_POST['fname']." ".$_POST['lname'] . "\r\n" ;
$message .= "E-mail: ".$_POST['email'] . "\r\n";
$message .= "Country: ".$_POST['country'] ."\r\n";
$message .= "phone No: ". $_POST['phone'] . "\r\n";
$message .= "Company Name: " . $_POST['company'] . "\r\n";
$message .= $_POST['message'];

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: '.$from . "\r\n";


// echo $to, $subject, $message, $headers;
mail($to, $subject, $message, $headers);


?>